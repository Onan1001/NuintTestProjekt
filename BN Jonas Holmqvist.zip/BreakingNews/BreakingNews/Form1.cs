﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BreakingNews
{
    public partial class Form1 : Form
    {
        private IWebCollector _webCollector;
        private IWebCalculator _webCalculator;

        public Form1()
        {
            _webCollector = new WebCollector();
            _webCalculator = new WebCalculator();
            InitializeComponent();
        }
        private async Task Loading()
        {
            textBoxcalc.Text = "Loading...";
            await Task.Delay(1500);
        }

        public string RbGetHttp()
        {
            if (radioButtonaftonbladet.Checked)
                return "https://www.aftonbladet.se/";

            if (radioButtonexpressen.Checked)
                return "https://www.expressen.se/";

            return radioButtondn.Checked ? "https://www.dn.se/" : String.Empty;
        }

        public async void GetNewsResult()
        {
            if (radioButtonkorea.Checked)
            {
                await Loading();
                await Task.Run(() => _webCollector.GetHtmlFromUrl(RbGetHttp()));
                textBoxcalc.Text = _webCalculator.CalcNumberOfHits(_webCollector, radioButtonkorea.Text.ToLower()).ToString();
            }
            if (radioButtonmello.Checked)
            {
                await Loading();
                await Task.Run(() => _webCollector.GetHtmlFromUrl(RbGetHttp()));
                textBoxcalc.Text = _webCalculator.CalcNumberOfHits(_webCollector, radioButtonmello.Text.ToLower()).ToString();
            }
            if (radioButtonekonomi.Checked)
            {
                await Loading();
                await Task.Run(() => _webCollector.GetHtmlFromUrl(RbGetHttp()));
                textBoxcalc.Text = _webCalculator.CalcNumberOfHits(_webCollector, radioButtonekonomi.Text.ToLower()).ToString();
            }
            if (radioButtonpolis.Checked)
            {
                await Loading();
                await Task.Run(() => _webCollector.GetHtmlFromUrl(RbGetHttp()));
                textBoxcalc.Text = _webCalculator.CalcNumberOfHits(_webCollector, radioButtonpolis.Text.ToLower()).ToString();
            }
        }
        private void GetstatsButton_Click(object sender, EventArgs e)
        {
            GetNewsResult();
        }
    }
}
