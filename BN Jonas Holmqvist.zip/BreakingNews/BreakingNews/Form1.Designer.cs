﻿namespace BreakingNews
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.getstatsButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonpolis = new System.Windows.Forms.RadioButton();
            this.radioButtonekonomi = new System.Windows.Forms.RadioButton();
            this.radioButtonmello = new System.Windows.Forms.RadioButton();
            this.radioButtonkorea = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButtondn = new System.Windows.Forms.RadioButton();
            this.radioButtonexpressen = new System.Windows.Forms.RadioButton();
            this.radioButtonaftonbladet = new System.Windows.Forms.RadioButton();
            this.textBoxcalc = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // getstatsButton
            // 
            this.getstatsButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getstatsButton.Location = new System.Drawing.Point(22, 172);
            this.getstatsButton.Name = "getstatsButton";
            this.getstatsButton.Size = new System.Drawing.Size(355, 38);
            this.getstatsButton.TabIndex = 9;
            this.getstatsButton.Text = "Get Statistics";
            this.getstatsButton.UseVisualStyleBackColor = true;
            this.getstatsButton.Click += new System.EventHandler(this.GetstatsButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(164, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 19);
            this.label1.TabIndex = 11;
            this.label1.Text = "Results";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonpolis);
            this.groupBox1.Controls.Add(this.radioButtonekonomi);
            this.groupBox1.Controls.Add(this.radioButtonmello);
            this.groupBox1.Controls.Add(this.radioButtonkorea);
            this.groupBox1.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(22, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(143, 141);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Keyword search settings";
            // 
            // radioButtonpolis
            // 
            this.radioButtonpolis.AutoSize = true;
            this.radioButtonpolis.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonpolis.Location = new System.Drawing.Point(7, 91);
            this.radioButtonpolis.Name = "radioButtonpolis";
            this.radioButtonpolis.Size = new System.Drawing.Size(59, 23);
            this.radioButtonpolis.TabIndex = 3;
            this.radioButtonpolis.TabStop = true;
            this.radioButtonpolis.Text = "polis";
            this.radioButtonpolis.UseVisualStyleBackColor = true;
            // 
            // radioButtonekonomi
            // 
            this.radioButtonekonomi.AutoSize = true;
            this.radioButtonekonomi.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonekonomi.Location = new System.Drawing.Point(7, 68);
            this.radioButtonekonomi.Name = "radioButtonekonomi";
            this.radioButtonekonomi.Size = new System.Drawing.Size(86, 23);
            this.radioButtonekonomi.TabIndex = 2;
            this.radioButtonekonomi.TabStop = true;
            this.radioButtonekonomi.Text = "ekonomi";
            this.radioButtonekonomi.UseVisualStyleBackColor = true;
            // 
            // radioButtonmello
            // 
            this.radioButtonmello.AutoSize = true;
            this.radioButtonmello.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonmello.Location = new System.Drawing.Point(7, 44);
            this.radioButtonmello.Name = "radioButtonmello";
            this.radioButtonmello.Size = new System.Drawing.Size(129, 21);
            this.radioButtonmello.TabIndex = 1;
            this.radioButtonmello.TabStop = true;
            this.radioButtonmello.Text = "melodifestivalen";
            this.radioButtonmello.UseVisualStyleBackColor = true;
            // 
            // radioButtonkorea
            // 
            this.radioButtonkorea.AutoSize = true;
            this.radioButtonkorea.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonkorea.Location = new System.Drawing.Point(7, 20);
            this.radioButtonkorea.Name = "radioButtonkorea";
            this.radioButtonkorea.Size = new System.Drawing.Size(66, 23);
            this.radioButtonkorea.TabIndex = 0;
            this.radioButtonkorea.TabStop = true;
            this.radioButtonkorea.Text = "korea";
            this.radioButtonkorea.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtondn);
            this.groupBox2.Controls.Add(this.radioButtonexpressen);
            this.groupBox2.Controls.Add(this.radioButtonaftonbladet);
            this.groupBox2.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(211, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(166, 141);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Site search settings";
            // 
            // radioButtondn
            // 
            this.radioButtondn.AutoSize = true;
            this.radioButtondn.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtondn.Location = new System.Drawing.Point(6, 97);
            this.radioButtondn.Name = "radioButtondn";
            this.radioButtondn.Size = new System.Drawing.Size(48, 23);
            this.radioButtondn.TabIndex = 2;
            this.radioButtondn.TabStop = true;
            this.radioButtondn.Text = "DN";
            this.radioButtondn.UseVisualStyleBackColor = true;
            // 
            // radioButtonexpressen
            // 
            this.radioButtonexpressen.AutoSize = true;
            this.radioButtonexpressen.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonexpressen.Location = new System.Drawing.Point(7, 59);
            this.radioButtonexpressen.Name = "radioButtonexpressen";
            this.radioButtonexpressen.Size = new System.Drawing.Size(93, 23);
            this.radioButtonexpressen.TabIndex = 1;
            this.radioButtonexpressen.TabStop = true;
            this.radioButtonexpressen.Text = "Expressen";
            this.radioButtonexpressen.UseVisualStyleBackColor = true;
            // 
            // radioButtonaftonbladet
            // 
            this.radioButtonaftonbladet.AutoSize = true;
            this.radioButtonaftonbladet.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonaftonbladet.Location = new System.Drawing.Point(7, 20);
            this.radioButtonaftonbladet.Name = "radioButtonaftonbladet";
            this.radioButtonaftonbladet.Size = new System.Drawing.Size(107, 23);
            this.radioButtonaftonbladet.TabIndex = 0;
            this.radioButtonaftonbladet.TabStop = true;
            this.radioButtonaftonbladet.Text = "Aftonbladet";
            this.radioButtonaftonbladet.UseVisualStyleBackColor = true;
            // 
            // textBoxcalc
            // 
            this.textBoxcalc.BackColor = System.Drawing.SystemColors.HotTrack;
            this.textBoxcalc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxcalc.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxcalc.Location = new System.Drawing.Point(132, 235);
            this.textBoxcalc.Name = "textBoxcalc";
            this.textBoxcalc.Size = new System.Drawing.Size(117, 17);
            this.textBoxcalc.TabIndex = 14;
            this.textBoxcalc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(406, 300);
            this.Controls.Add(this.textBoxcalc);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.getstatsButton);
            this.Name = "Form1";
            this.Text = "Breaking News";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button getstatsButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtonpolis;
        private System.Windows.Forms.RadioButton radioButtonekonomi;
        private System.Windows.Forms.RadioButton radioButtonmello;
        private System.Windows.Forms.RadioButton radioButtonkorea;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButtondn;
        private System.Windows.Forms.RadioButton radioButtonexpressen;
        private System.Windows.Forms.RadioButton radioButtonaftonbladet;
        private System.Windows.Forms.TextBox textBoxcalc;
    }
}

