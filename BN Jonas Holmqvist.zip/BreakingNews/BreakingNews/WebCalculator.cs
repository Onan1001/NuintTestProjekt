﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace BreakingNews
{

    public class WebCalculator : IWebCalculator
    {
        public int CalcNumberOfHits(IWebCollector webcount, string keyword)
        {
            if (  string.IsNullOrEmpty(webcount.HtmlCode) || string.IsNullOrEmpty(keyword) || webcount == null)
            {
                return -1;
            }
            return Regex.Matches(webcount.HtmlCode.ToLower(), keyword).Count;
        }
    }
}
