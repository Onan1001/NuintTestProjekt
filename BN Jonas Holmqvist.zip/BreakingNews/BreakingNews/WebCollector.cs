﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using BreakingNews;


namespace BreakingNews
{
    

    public class WebCollector: IWebCollector
    {
        public string HtmlCode { get; set; }
        public void GetHtmlFromUrl(string url)
        {
            if (string.IsNullOrEmpty(url))
            {
                throw new ArgumentNullException("Cant be Null or Empty");
            }

            if (!url.Contains("https"))
            {
                throw new ArgumentException("No Https!");
            }

            if (url.Contains("https"))
            {
                using (HttpClient client = new HttpClient())
                {
                    using (HttpResponseMessage response = client.GetAsync(url).Result)
                    {
                        using (HttpContent content = response.Content)
                        {
                            HtmlCode = content.ReadAsStringAsync().Result;
                        }
                    }
                }

            }
           
        }
        
    }
}
