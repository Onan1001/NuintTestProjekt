﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace BreakingNews
{
    public interface IWebCollector
    {
        /// <summary>/// 
        /// Html code from last search
        /// /// </summary> 
        string HtmlCode { get; set; }

        /// <summary>
        /// Pooulate the HtmlCode-property withhtml code from given URL.
        /// Sets the HtmlCode-property tostring.Empty if url is NULL,empty or
        /// not containing "http".
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        void GetHtmlFromUrl(string url);
    }
}
