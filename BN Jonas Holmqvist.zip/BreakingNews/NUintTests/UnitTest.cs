﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using BreakingNews;
using Moq;
using NUnit.Framework;

namespace NUintTests
{
    [TestFixture]
    public class UnitTest
    {

        [Test]
        public void TestEmptyOrNullUrl()
        {
            var wc = new WebCollector();
            var nullstring = Assert.Throws<ArgumentNullException>(
                () => wc.GetHtmlFromUrl(null));
            Assert.IsTrue(nullstring.Message.Contains("Cant be Null or Empty"));

            var emptystring = Assert.Throws<ArgumentNullException>(() => wc.GetHtmlFromUrl(string.Empty));
            Assert.IsTrue(emptystring.Message.Contains("Cant be Null or Empty"));
        }

        [Test]
        public void TestUrlWithoutHttp()
        {
            var wc = new WebCollector();
            var url = "www.dn.se";
            var nohttp = Assert.Throws<ArgumentException>(() => wc.GetHtmlFromUrl(url));
            Assert.IsTrue(nohttp.Message.Contains("No Https!"));

        }

        [Test]
        public void WithHttp()
        {
            var wc = new WebCollector();
            string http = "https://www.dn.se/";
            wc.GetHtmlFromUrl(http);
            Assert.IsTrue(http.Contains("https"));
        }

        [Test]
        public void NullObjectWebCalc()
        {
            IWebCalculator wc = new WebCalculator();
            IWebCollector wd = new WebCollector();
            string keyword = "testing";
            var result = wc.CalcNumberOfHits(wd, keyword);
            Assert.AreEqual(-1, result);
        }

        [Test]
        public void HtmlNull()
        {
            IWebCalculator wc = new WebCalculator();
            IWebCollector wd = new WebCollector();
            string keyword = "Testing";
            wd.HtmlCode = null;
            var result = wc.CalcNumberOfHits(wd, keyword);
            Assert.AreEqual(-1, result);
        }

        [Test]
        public void EmptyStringHtml()
        {
            IWebCalculator wc = new WebCalculator();
            IWebCollector wd = new WebCollector();
            string keyword = "Testing";
            wd.HtmlCode = String.Empty;
            var result = wc.CalcNumberOfHits(wd, keyword);
            Assert.AreEqual(-1, result);
        }

        [Test]
        public void KeywordNull()
        {
            IWebCalculator wc = new WebCalculator();
            IWebCollector wd = new WebCollector();
            string keyword = null;
            wd.HtmlCode = "Test";
            var result = wc.CalcNumberOfHits(wd, keyword);
            Assert.AreEqual(-1, result);
        }

        [Test]
        public void KeywordStringEmpty()
        {
            IWebCalculator wc = new WebCalculator();
            IWebCollector wd = new WebCollector();
            string keyword = String.Empty;
            wd.HtmlCode = "Test";
            var result = wc.CalcNumberOfHits(wd, keyword);
            Assert.AreEqual(-1, result);
        }

        [Test]
        public void MoqTest()
        {
            Mock<IWebCollector> moq = new Mock<IWebCollector>();
            IWebCalculator wc = new WebCalculator();
            moq.Setup(x => x.HtmlCode).Returns("koreakoreakorea");
            string s = "korea";
            var result = wc.CalcNumberOfHits(moq.Object, s);
            Assert.That(result == 3);
        }
       
    }
}
